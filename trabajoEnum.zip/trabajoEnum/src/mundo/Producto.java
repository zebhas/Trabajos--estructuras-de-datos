/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

/**
 *
 * @author Guest
 */
public class Producto {

	protected double precio;

	public Producto(double pPrecio)
	{
		precio = pPrecio;
	}

}